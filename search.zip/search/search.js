const searchFunction = () => {
    let filter = document.getElementById('myInput').value.toUpperCase();
    let myTable = document.getElementById('table');
    let tr = myTable.getElementsByTagName('tr');

    for (var i = 0; i < tr.length; i++) {
        let td = tr[i].getElementsByTagName('td')[0];

        if (td) {
            let textValue = td.textContent.toUpperCase() || td.innerHTML.toUpperCase();

            if (textValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
                console.log('TEST')
            }
            else {
                tr[i].style.display = "none";
            }

        }

    }
}
